import { useEffect, useState } from 'react'
import { onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, updateProfile, type User } from 'firebase/auth'
import { addDoc, collection, onSnapshot, orderBy, query, serverTimestamp, doc, setDoc, updateDoc, increment } from 'firebase/firestore'
import { auth, db, firebaseReady } from './firebase'
import { BookOpen, Cross, Heart, Home, LogIn, LogOut, Menu, MessageCircle, Radio, Send, Users, X } from 'lucide-react'

type Lesson = { id: string; title: string; category: string; body: string; reference: string; likes: number }
type Post = { id: string; text: string; author: string; createdAt?: { toDate: () => Date } }
const initialLessons: Lesson[] = [
  { id:'jesus', title:'Yesuus eenyu?', category:'Yesuus Kiristoos', body:'Yesuus Kiristoos Gooftaa fi Fayyisaa dha. Barumsa waa’ee eenyummaa isaa Macaafa Qulqulluu keessatti qoranna.', reference:'Yohannis 14:6; Yohannis 1:1–14', likes:0 },
  { id:'eternal', title:'Jireenya bara baraa', category:'Jireenya bara baraa', body:'Jireenyi bara baraa kennaa Waaqayyoo kan Yesuus Kiristoos keessatti argamu dha. Barumsi kun abdii fi hiika jireenyaa ibsa.', reference:'Yohannis 3:16; Roomaa 6:23', likes:0 },
  { id:'bible', title:'Macaafa Qulqulluu dubbisuu', category:'Barumsa Macaafa Qulqulluu', body:'Macaafa Qulqulluu kadhannaadhaan dubbisi; kutaa dubbiste hubadhu, gaaffii gaafadhu, hojii irra oolchi.', reference:'2 Ximotewos 3:16–17', likes:0 },
  { id:'dialogue', title:'Marii amantii kabajaan', category:'Qorannoo amantii', body:'Barsiisa amantii garaagaraa madda isaanii waliin qoranna. Namoota kabajna; yaada, hiika fi ragaa wal irraa adda baasna.', reference:'1 Phexros 3:15', likes:0 }
]
const nav = [
  {id:'home',label:'Mana',icon:Home},{id:'lessons',label:'Barumsa',icon:BookOpen},{id:'community',label:'Miseensota',icon:Users},{id:'channels',label:'Channels',icon:Radio},{id:'chat',label:'Chat',icon:MessageCircle}
]
export default function App() {
  const [user,setUser] = useState<User|null>(null)
  const [page,setPage] = useState('home')
  const [menu,setMenu] = useState(false)
  const [email,setEmail] = useState(''), [password,setPassword] = useState(''), [name,setName] = useState('')
  const [register,setRegister] = useState(true), [authError,setAuthError] = useState('')
  const [posts,setPosts] = useState<Post[]>([])
  const [postText,setPostText] = useState('')
  const [lessons,setLessons] = useState(initialLessons)
  const [liked,setLiked] = useState<string[]>([])
  const [chatText,setChatText] = useState('')
  const [channel,setChannel] = useState('Barumsa Macaafa Qulqulluu')

  useEffect(() => {
    if (!auth) return
    return onAuthStateChanged(auth, setUser)
  }, [])
  useEffect(() => {
    if (!db) return
    const q = query(collection(db,'posts'),orderBy('createdAt','desc'))
    return onSnapshot(q,s => setPosts(s.docs.map(d=>({id:d.id,...d.data()} as Post))),()=>{})
  }, [])
  useEffect(() => {
    if (!db) return
    const q = query(collection(db,'lessons'),orderBy('createdAt','desc'))
    return onSnapshot(q,s => {
      if (s.docs.length) setLessons(s.docs.map(d=>({id:d.id,...d.data()} as Lesson)))
    },()=>{})
  }, [])
  async function submitAuth(e:React.FormEvent) {
    e.preventDefault(); setAuthError('')
    if (!auth) { setAuthError('Firebase hin qindaa’inne. .env.local guuti; README ilaali.'); return }
    try {
      if (register) {
        const cred = await createUserWithEmailAndPassword(auth,email,password)
        await updateProfile(cred.user,{displayName:name.trim()})
        if (db) await setDoc(doc(db,'users',cred.user.uid),{displayName:name.trim(),email,role:'member',createdAt:serverTimestamp(),photoURL:''})
      } else await signInWithEmailAndPassword(auth,email,password)
    } catch(err) { setAuthError(err instanceof Error ? err.message : 'Dogoggorri uumame.') }
  }
  async function publishPost(e:React.FormEvent) {
    e.preventDefault()
    if (!db || !user || !postText.trim()) return
    await addDoc(collection(db,'posts'),{text:postText.trim(),author:user.displayName||user.email||'Miseensa',uid:user.uid,createdAt:serverTimestamp(),likes:0})
    setPostText('')
  }
  async function likeLesson(id:string) {
    if (liked.includes(id)) return
    setLiked(v=>[...v,id])
    if (db) await updateDoc(doc(db,'lessons',id),{likes:increment(1)}).catch(()=>{})
    setLessons(v=>v.map(l=>l.id===id?{...l,likes:l.likes+1}:l))
  }
  async function sendChat(e:React.FormEvent) {
    e.preventDefault()
    if (!db || !user || !chatText.trim()) return
    await addDoc(collection(db,'messages'),{text:chatText.trim(),author:user.displayName||user.email,uid:user.uid,channel,createdAt:serverTimestamp()})
    setChatText('')
  }
  if (!user) return <main className="auth-screen"><div className="auth-card"><Brand/><p className="eyebrow">GAREE DHUGAA BAATUU</p><h1>{register?'Miseensa ta’i':'Baga deebite'}</h1><p className="muted">Baradhu, barsiisi, wal jajjabeessi.</p>
    <form onSubmit={submitAuth}>{register&&<label>Maqaa guutuu<input required value={name} onChange={e=>setName(e.target.value)} placeholder="Maqaa kee"/></label>}<label>Email<input required type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="email@example.com"/></label><label>Password<input required minLength={6} type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Yoo xiqqaate qubee 6"/></label>{authError&&<p className="error">{authError}</p>}<button className="primary full" type="submit">{register?'Account bani':'Seeni'} <LogIn size={17}/></button></form>
    <button className="text-button" onClick={()=>{setRegister(!register);setAuthError('')}}>{register?'Account qabdaa? Seeni':'Account hin qabduu? Galmaa’i'}</button>
    {!firebaseReady&&<p className="setup-note">Hubachiisa: fuulli appii kun ni banama; galmeen dhugaa hojjechuuf Firebase qindeessuun barbaachisa.</p>}
  </div></main>
  return <div className="app-shell"><header className="topbar"><button className="icon-btn mobile-only" onClick={()=>setMenu(!menu)}>{menu?<X/>:<Menu/>}</button><Brand/><div className="top-user"><span>{user.displayName||user.email}</span><button className="icon-btn" title="Ba’i" onClick={()=>auth&&signOut(auth)}><LogOut size={18}/></button></div></header>
    <div className="layout"><aside className={menu?'sidebar show':'sidebar'}><p className="side-label">MENU</p>{nav.map(n=><button key={n.id} className={page===n.id?'nav-item active':'nav-item'} onClick={()=>{setPage(n.id);setMenu(false)}}><n.icon size={19}/>{n.label}</button>)}<div className="side-verse">“Waaqayyo iddoo bal’ina nuuf kenneera.”<b>Uumama 26:22</b></div></aside>
    <main className="content">{page==='home'&&<><section className="hero"><div><p className="eyebrow">BAGA NAGAAN DHUFTAN</p><h1>REHOBOTH keessatti<br/>wal baranna, wal ijaarra.</h1><p>Barumsa Macaafa Qulqulluu, marii fi tokkummaa Kiristaanaa.</p><button className="light-btn" onClick={()=>setPage('lessons')}>Barumsa jalqabi <BookOpen size={17}/></button></div><div className="hero-cross"><Cross size={94}/></div></section><div className="section-head"><div><p className="eyebrow">QO’ANNOO</p><h2>Barumsa filatamoo</h2></div><button className="link-btn" onClick={()=>setPage('lessons')}>Hunda ilaali</button></div><div className="lesson-grid">{lessons.slice(0,3).map(l=><LessonCard key={l.id} lesson={l} liked={liked.includes(l.id)} onLike={()=>likeLesson(l.id)}/>)}</div><section className="feed"><h2>Yaada miseensotaa</h2><PostComposer value={postText} setValue={setPostText} onSubmit={publishPost} user={user}/><PostList posts={posts}/></section></>}
    {page==='lessons'&&<><PageTitle eyebrow="BARUMSA" title="Macaafa Qulqulluu baradhu" desc="Barumsa, ragaa Macaafa Qulqulluu fi marii itti fufiinsa qabu."/><div className="lesson-grid">{lessons.map(l=><LessonCard key={l.id} lesson={l} liked={liked.includes(l.id)} onLike={()=>likeLesson(l.id)}/>)}</div></>}
    {page==='community'&&<><PageTitle eyebrow="TOKKUMMAA" title="Miseensota" desc="Miseensota REHOBOTH waliin wal baradhu."/><div className="empty-card"><Users size={34}/><h3>Miseensota</h3><p>Galmeen miseensotaa yeroo Firebase qindaa’u ni hojjetti. Account kee nageenyaan eegi; odeeffannoo dhuunfaa hin qoodin.</p></div></>}
    {page==='channels'&&<><PageTitle eyebrow="BARUMSA WALOO" title="Channels" desc="Marii fi barumsa mata duree mata dureedhaan."/><div className="channel-list">{['Barumsa Macaafa Qulqulluu','Waa’ee Yesuus','Jireenya Bara Baraa','Gaaffii fi Deebii','Dhugaa Baatummaa','Kadhannaa','Qorannoo Amantii'].map(c=><button className={channel===c?'channel active-channel':'channel'} key={c} onClick={()=>{setChannel(c);setPage('chat')}}><Radio size={19}/><span>{c}</span><span className="arrow">›</span></button>)}</div></>}
    {page==='chat'&&<><PageTitle eyebrow="WALQUNNAMTII" title={channel} desc="Ergaa channel kanaaf barreessi. Miseensonni seene qofatu ergaa erguu danda’a."/><div className="empty-card"><MessageCircle size={32}/><h3>Chat channel</h3><p>Ergaan yeroo Firebase fi Firestore rules qindaa’an yeroo dhugaa keessatti ni mul’ata.</p><form className="composer" onSubmit={sendChat}><input value={chatText} onChange={e=>setChatText(e.target.value)} placeholder="Ergaa kee barreessi..."/><button className="primary" disabled={!firebaseReady}><Send size={17}/> Ergi</button></form></div></>}
    </main></div><footer>© REHOBOTH · Wal baradhu · Wal barsiisi · Wal jajjabeessi</footer></div>
}
function Brand(){return <div className="brand"><div className="brand-mark"><Cross size={22}/></div><div><strong>REHOBOTH</strong><small>GAREE DHUGAA BAATUU</small></div></div>}
function PageTitle({eyebrow,title,desc}:{eyebrow:string,title:string,desc:string}){return <div className="page-title"><p className="eyebrow">{eyebrow}</p><h1>{title}</h1><p className="muted">{desc}</p></div>}
function LessonCard({lesson,liked,onLike}:{lesson:Lesson,liked:boolean,onLike:()=>void}){return <article className="lesson-card"><span className="tag">{lesson.category}</span><h3>{lesson.title}</h3><p>{lesson.body}</p><b className="reference">{lesson.reference}</b><div className="card-bottom"><span>Barumsa</span><button className={liked?'like liked':'like'} onClick={onLike}><Heart size={17} fill={liked?'currentColor':'none'}/> {lesson.likes}</button></div></article>}
function PostComposer({value,setValue,onSubmit,user}:{value:string,setValue:(s:string)=>void,onSubmit:(e:React.FormEvent)=>void,user:User}){return <form className="composer post-composer" onSubmit={onSubmit}><div className="avatar">{(user.displayName||'R')[0].toUpperCase()}</div><input value={value} onChange={e=>setValue(e.target.value)} placeholder="Yaada ykn barumsa kee qoodi..."/><button className="primary" type="submit"><Send size={17}/> Maxxansi</button></form>}
function PostList({posts}:{posts:Post[]}){return <div className="post-list">{posts.length===0?<p className="muted">Ammaaf yaadni hin jiru. Yaada jalqabaa qoodi.</p>:posts.map(p=><article className="post" key={p.id}><div className="avatar">{(p.author||'M')[0].toUpperCase()}</div><div><b>{p.author}</b><p>{p.text}</p></div></article>)}</div>}
